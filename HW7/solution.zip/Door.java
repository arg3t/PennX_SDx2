public class Door extends MapSite{
    public boolean isOpen;
    public Room room1;
    public Room room2;

    @Override 
    public void enter(){

    }
}
