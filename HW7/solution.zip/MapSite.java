public abstract class MapSite{
    public void enter(){

    };
}
