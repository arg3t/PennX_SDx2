public class Maze{
    public Room[] rooms;

    public void addRoom(Room r){

    }
}
