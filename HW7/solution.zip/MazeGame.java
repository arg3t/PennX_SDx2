public class MazeGame{
    public Maze createMaze(){
        return null;
    }
    public void loadMaze(){

    }
}
