public class RandomizedMazeGame extends MazeGame{
    public Maze randomize(int seed){
        return null;
    }
}
