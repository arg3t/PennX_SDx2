public class Room extends MapSite{
    public int roomNumber;
    public MapSite[] mapsites;
    public Wall[] sides;

    public Wall getSide(int foo){
        return null;
    }

    public void setSide(int foo, Wall wall){

    }
}
