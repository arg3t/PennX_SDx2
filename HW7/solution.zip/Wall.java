public class Wall{

}
